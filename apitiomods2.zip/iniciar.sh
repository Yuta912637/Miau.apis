#!bin/bash
GREEN='\033[0;32m'
while : 
do
echo "${GREEN}Sabrina API 2023 - _ Auto reconexão ativada para prevenção de quedas.."
    node api.js
    sleep 1

done
