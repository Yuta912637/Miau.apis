module.exports = {
...(require('./pesquisas.js')),
...(require('./downloaders.js')),
...(require('./noticias.js'))
}