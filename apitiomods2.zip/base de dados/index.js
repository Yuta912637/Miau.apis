module.exports = {
	Vokal: require('./utils/vokal'),
	Base: require('./utils/base'),
	Searchnabi: require('./utils/kisahnabi'),
        Gempa: require('./utils/gempa')
}
