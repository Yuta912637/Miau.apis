const mumaker = require("./index")

mumaker.textpro("https://textpro.me/create-blackpink-logo-style-online-1001.html", "Dika Ardnt.")
.then(console.log)
.catch(console.error)