exports.textpro = require("./src/maker")
exports.photooxy = require("./src/maker")
exports.ephoto = require("./src/maker")
exports.tiktok = require("./src/downloader").tiktok
exports.instagram = require("./src/downloader").instagram
exports.facebook = require("./src/downloader").facebook