module.exports = require("./src/Canvas");
